UPDATE `t_config` SET `catid` = '1' WHERE `id` = 8;
