INSERT INTO `t_config` (`id`, `catid`, `name`, `value`, `tag`, `lock`, `updatetime`) VALUES
(20, 1, 'layerad', '', '弹窗广告', 1, 1453452674);