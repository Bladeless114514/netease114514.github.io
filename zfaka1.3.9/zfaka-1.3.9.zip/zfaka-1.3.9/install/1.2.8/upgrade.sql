INSERT INTO `t_config` (`id`, `catid`, `name`, `value`, `tag`, `lock`, `updatetime`) VALUES (26, 1, 'discountswitch', '0', '折扣开关', 1, 1453452674);
